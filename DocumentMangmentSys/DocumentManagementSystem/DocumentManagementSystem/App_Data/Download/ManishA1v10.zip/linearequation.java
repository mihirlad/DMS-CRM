import java.util.Scanner;
public class linearequation {
		private static Scanner in;
		public static void main(String[] args)
		{
		in = new Scanner(System.in);  
	      //Test numbers 3.4, 50.2, 2.1, 0.55, 44.5, 5.9;
	      System.out.print("Enter a, b, c, d, e, f: ");
	      double a = in.nextDouble();
	      double b = in.nextDouble();
	      double c = in.nextDouble();
	      double d = in.nextDouble();
	      double e = in.nextDouble();
	      double f = in.nextDouble();
	 
	      {
	         double x = ((e * d) - (b * f)) / ((a * d) - (b * c));
	         double y = ((a * f) - (e * c)) / ((a * d) - (b * c));
	         System.out.println("x = " + x + " and " + "y = " + y);
	      }
	   }
	}
