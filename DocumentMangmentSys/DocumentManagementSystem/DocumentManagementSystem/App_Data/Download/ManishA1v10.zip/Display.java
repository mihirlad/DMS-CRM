package manish;

public class Display {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        System.out.println("Welcome to java");
        System.out.println("Welcome to computer science");
        System.out.println("Program is fun");
        
	}

}
